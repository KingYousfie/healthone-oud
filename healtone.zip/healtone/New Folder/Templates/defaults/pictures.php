<figure>
    <img class="banner-img img-fluid" src='/img/mqdefault.jpg' />
</figure>


