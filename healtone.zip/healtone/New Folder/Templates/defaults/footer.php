<footer >
    <p class="clearfix pb-3  text-muted text-center" > <span class="text-warning"> &copy;healtone  locatie zoetermeer 2751GE .</span></p>
</footer>
